# __init__.py: tell python the whole directory here should be treated as a package
from .main import aloha # this line is more like a function registry for letting developer to import o the function aloha and use it ~

# when we use the package, how?
# do the following import
# from alohapy import aloha