# This file is used for how to bundling and publishing the package ~
from setuptools import setup, find_packages

setup(
  name="alohapy",
  version="0.1",
  packages=find_packages(),
  install_requires=[]
)
