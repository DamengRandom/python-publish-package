def aloha():
  print("Aloha from Damon ~")